ESX = exports["es_extended"]:getSharedObject()

local function GenerateIBAN()
    local country = "DE"
    local numbers = ""
    for i = 1, 20 do
        numbers = numbers .. math.random(0,9)
    end
    return country .. numbers:sub(1,2) .. " " ..
           numbers:sub(3,6) .. " " ..
           numbers:sub(7,10) .. " " ..
           numbers:sub(11,14) .. " " ..
           numbers:sub(15,18) .. " " ..
           numbers:sub(19,20)
end

local function FormatIBAN(iban)
    return string.gsub(iban, "%s+", "")
end

local function FormatIBANDisplay(iban)
    local cleanIBAN = FormatIBAN(iban)
    return string.format("%s %s %s %s %s %s",
        string.sub(cleanIBAN, 1, 4),
        string.sub(cleanIBAN, 5, 8),
        string.sub(cleanIBAN, 9, 12),
        string.sub(cleanIBAN, 13, 16),
        string.sub(cleanIBAN, 17, 20),
        string.sub(cleanIBAN, 21, 22)
    )
end

local function UpdatePlayerData(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return end

    MySQL.Async.fetchScalar('SELECT iban FROM banking_accounts WHERE identifier = @identifier', {
        ['@identifier'] = xPlayer.identifier
    }, function(iban)
        if iban then
            TriggerClientEvent('banking:setIBAN', source, iban)
        end
    end)

    TriggerClientEvent('banking:setBalance', source, xPlayer.getAccount('bank').money)

    MySQL.Async.fetchAll('SELECT * FROM banking_transactions WHERE identifier = @identifier ORDER BY date DESC LIMIT 10',
    {['@identifier'] = xPlayer.identifier},
    function(transactions)
        TriggerClientEvent('banking:setTransactions', source, transactions)
    end)
end

RegisterServerEvent('banking:initializeAccount')
AddEventHandler('banking:initializeAccount', function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    
    if not xPlayer then return end

    MySQL.Async.fetchScalar('SELECT iban FROM banking_accounts WHERE identifier = @identifier', {
        ['@identifier'] = xPlayer.identifier
    }, function(existingIBAN)
        if not existingIBAN then
            local newIBAN = GenerateIBAN()
            MySQL.Async.execute('INSERT INTO banking_accounts (identifier, iban) VALUES (@identifier, @iban)', {
                ['@identifier'] = xPlayer.identifier,
                ['@iban'] = newIBAN
            }, function()
                UpdatePlayerData(_source)
            end)
        else
            UpdatePlayerData(_source)
        end
    end)
end)

RegisterServerEvent('banking:deposit')
AddEventHandler('banking:deposit', function(amount)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    
    if not xPlayer or amount <= 0 then return end
    
    if xPlayer.getMoney() >= amount then
        xPlayer.removeMoney(amount)
        xPlayer.addAccountMoney('bank', amount)
        
        MySQL.Async.execute('INSERT INTO banking_transactions (identifier, type, amount, date) VALUES (@identifier, @type, @amount, @date)',
        {
            ['@identifier'] = xPlayer.identifier,
            ['@type'] = 'deposit',
            ['@amount'] = amount,
            ['@date'] = os.date('%Y-%m-%d %H:%M:%S')
        }, function()
            UpdatePlayerData(_source)
            TriggerClientEvent('esx:showNotification', _source, 'Du hast ' .. amount .. '$ eingezahlt')
        end)
    else
        TriggerClientEvent('esx:showNotification', _source, 'Du hast nicht genug Bargeld dabei')
    end
end)

RegisterServerEvent('banking:withdraw')
AddEventHandler('banking:withdraw', function(amount)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    
    if not xPlayer or amount <= 0 then return end
    
    if xPlayer.getAccount('bank').money >= amount then
        xPlayer.removeAccountMoney('bank', amount)
        xPlayer.addMoney(amount)
        
        MySQL.Async.execute('INSERT INTO banking_transactions (identifier, type, amount, date) VALUES (@identifier, @type, @amount, @date)',
        {
            ['@identifier'] = xPlayer.identifier,
            ['@type'] = 'withdraw',
            ['@amount'] = amount,
            ['@date'] = os.date('%Y-%m-%d %H:%M:%S')
        }, function()
            UpdatePlayerData(_source)
            TriggerClientEvent('esx:showNotification', _source, 'Du hast ' .. amount .. '$ abgehoben')
        end)
    else
        TriggerClientEvent('esx:showNotification', _source, 'Du hast nicht genug Geld auf dem Konto')
    end
end)

RegisterServerEvent('banking:transfer')
AddEventHandler('banking:transfer', function(targetIBAN, amount)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    
    if not xPlayer or amount <= 0 then return end

    local formattedTargetIBAN = FormatIBAN(targetIBAN)

    MySQL.Async.fetchScalar('SELECT iban FROM banking_accounts WHERE identifier = @identifier', {
        ['@identifier'] = xPlayer.identifier
    }, function(sourceIBAN)
        if not sourceIBAN then return end

        if FormatIBAN(sourceIBAN) == formattedTargetIBAN then
            TriggerClientEvent('esx:showNotification', _source, 'Du kannst kein Geld an dich selbst überweisen')
            return
        end

        MySQL.Async.fetchAll('SELECT identifier FROM banking_accounts WHERE REPLACE(iban, " ", "") = @iban', {
            ['@iban'] = formattedTargetIBAN
        }, function(result)
            if result and #result > 0 then
                local targetIdentifier = result[1].identifier
                local tPlayer = ESX.GetPlayerFromIdentifier(targetIdentifier)

                if xPlayer.getAccount('bank').money >= amount then
                    xPlayer.removeAccountMoney('bank', amount)
                    
                    if tPlayer then
                        tPlayer.addAccountMoney('bank', amount)
                    else
                        MySQL.Async.execute('UPDATE users SET bank = bank + @amount WHERE identifier = @identifier',
                        {
                            ['@amount'] = amount,
                            ['@identifier'] = targetIdentifier
                        })
                    end
                    
                    MySQL.Async.execute('INSERT INTO banking_transactions (identifier, type, amount, date, source_iban, target_iban) VALUES (@identifier, @type, @amount, @date, @source_iban, @target_iban)',
                    {
                        ['@identifier'] = xPlayer.identifier,
                        ['@type'] = 'transfer_sent',
                        ['@amount'] = amount,
                        ['@date'] = os.date('%Y-%m-%d %H:%M:%S'),
                        ['@source_iban'] = sourceIBAN,
                        ['@target_iban'] = FormatIBANDisplay(targetIBAN)
                    })

                    MySQL.Async.execute('INSERT INTO banking_transactions (identifier, type, amount, date, source_iban, target_iban) VALUES (@identifier, @type, @amount, @date, @source_iban, @target_iban)',
                    {
                        ['@identifier'] = targetIdentifier,
                        ['@type'] = 'transfer_received',
                        ['@amount'] = amount,
                        ['@date'] = os.date('%Y-%m-%d %H:%M:%S'),
                        ['@source_iban'] = sourceIBAN,
                        ['@target_iban'] = FormatIBANDisplay(targetIBAN)
                    })

                    UpdatePlayerData(_source)
                    if tPlayer then
                        UpdatePlayerData(tPlayer.source)
                    end
                    
                    TriggerClientEvent('esx:showNotification', _source, 'Überweisung erfolgreich: ' .. amount .. '$ an ' .. FormatIBANDisplay(targetIBAN))
                    if tPlayer then
                        TriggerClientEvent('esx:showNotification', tPlayer.source, 'Eingehende Überweisung: ' .. amount .. '$ von ' .. sourceIBAN)
                    end
                else
                    TriggerClientEvent('esx:showNotification', _source, 'Du hast nicht genug Geld auf dem Konto')
                end
            else
                TriggerClientEvent('esx:showNotification', _source, 'IBAN nicht gefunden')
            end
        end)
    end)
end)

RegisterServerEvent('banking:receiveSalary')
AddEventHandler('banking:receiveSalary', function(amount)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    
    if xPlayer and amount > 0 then
        xPlayer.addAccountMoney('bank', amount)
        
        MySQL.Async.execute('INSERT INTO banking_transactions (identifier, type, amount, date) VALUES (@identifier, @type, @amount, @date)',
        {
            ['@identifier'] = xPlayer.identifier,
            ['@type'] = 'paycheck',
            ['@amount'] = amount,
            ['@date'] = os.date('%Y-%m-%d %H:%M:%S')
        }, function()
            UpdatePlayerData(_source)
            TriggerClientEvent('esx:showNotification', _source, 'Du hast dein Gehalt von ' .. amount .. '$ erhalten')
        end)
    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer then
        TriggerEvent('banking:initializeAccount', source)
    end
end)

RegisterServerEvent('banking:getBalance')
AddEventHandler('banking:getBalance', function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    
    if xPlayer then
        TriggerClientEvent('banking:setBalance', _source, xPlayer.getAccount('bank').money)
    end
end)

RegisterServerEvent('banking:getTransactions')
AddEventHandler('banking:getTransactions', function()
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    
    if xPlayer then
        MySQL.Async.fetchAll('SELECT * FROM banking_transactions WHERE identifier = @identifier ORDER BY date DESC LIMIT 10',
        {['@identifier'] = xPlayer.identifier},
        function(transactions)
            TriggerClientEvent('banking:setTransactions', _source, transactions)
        end)
    end
end)