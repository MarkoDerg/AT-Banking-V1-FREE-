CREATE TABLE IF NOT EXISTS `banking_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identifier` varchar(60) NOT NULL,
  `iban` varchar(24) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `identifier_unique` (`identifier`),
  UNIQUE KEY `iban_unique` (`iban`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `banking_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identifier` varchar(60) NOT NULL,
  `type` varchar(50) NOT NULL,
  `amount` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `source_iban` varchar(24) DEFAULT NULL,
  `target_iban` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `identifier_index` (`identifier`),
  KEY `date_index` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `banking_transactions`
ADD CONSTRAINT `fk_transactions_identifier` 
FOREIGN KEY (`identifier`) REFERENCES `users` (`identifier`) 
ON DELETE CASCADE ON UPDATE CASCADE;