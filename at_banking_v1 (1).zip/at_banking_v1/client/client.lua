local ESX = nil
local display = false
local playerPed = nil
local playerCoords = nil
local atmCache = {}
local isNearATM = false
local currentATM = nil
local currentDist = 0
local sleep = 1000

CreateThread(function()
    while not ESX do
        ESX = exports["es_extended"]:getSharedObject()
        Wait(100)
    end
    
    playerPed = PlayerPedId()
    
    for _, atm in pairs(Config.ATMLocations) do
        local coords = vector3(atm.x, atm.y, atm.z)
        atmCache[#atmCache + 1] = coords
        
        local blip = AddBlipForCoord(coords.x, coords.y, coords.z)
        SetBlipSprite(blip, 108)
        SetBlipScale(blip, 0.7)
        SetBlipColour(blip, 2)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString("Bankautomat")
        EndTextCommandSetBlipName(blip)
    end

    TriggerServerEvent('banking:initializeAccount')
end)

local function OpenBankingUI()
    if display then return end
    
    display = true
    SetNuiFocus(true, true)
    SendNUIMessage({type = "ui", display = true})
    
    local playerData = ESX.GetPlayerData()
    SendNUIMessage({
        type = "playerInfo",
        firstName = playerData.firstName,
        lastName = playerData.lastName
    })
    
    TriggerServerEvent('banking:initializeAccount')
end

local function CloseBankingUI()
    if not display then return end
    
    display = false
    SetNuiFocus(false, false)
    SendNUIMessage({type = "ui", display = false})
end

local function GetClosestATM()
    if not playerCoords then return end
    
    local closest, minDist = nil, 10.0
    
    for i = 1, #atmCache do
        local dist = #(playerCoords - atmCache[i])
        if dist < minDist then
            minDist = dist
            closest = atmCache[i]
        end
    end
    
    return closest, minDist
end

CreateThread(function()
    while true do
        Wait(sleep)
        
        if not display then
            playerPed = PlayerPedId()
            playerCoords = GetEntityCoords(playerPed)
            currentATM, currentDist = GetClosestATM()
            
            if currentATM and currentDist < 10.0 then
                sleep = currentDist < 3.0 and 0 or 100
                
                if currentDist < 3.0 then
                    DrawMarker(2, currentATM.x, currentATM.y, currentATM.z + 0.3, 
                        0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 
                        0.3, 0.3, 0.3, 0, 255, 0, 100, 
                        false, true, 2, true, false, false, false)
                    
                    if currentDist < 1.5 then
                        if not isNearATM then
                            isNearATM = true
                            ESX.ShowHelpNotification('Drücke ~INPUT_CONTEXT~ um auf dein Bankkonto zuzugreifen')
                        end
                        
                        if IsControlJustPressed(0, 38) then
                            OpenBankingUI()
                        end
                    else
                        isNearATM = false
                    end
                end
            else
                sleep = 1000
                isNearATM = false
            end
        end
        
        if display and IsControlJustReleased(0, 177) then
            CloseBankingUI()
        end
    end
end)

RegisterNUICallback("close", function(_, cb)
    CloseBankingUI()
    cb('ok')
end)

RegisterNUICallback("deposit", function(data, cb)
    if data.amount and tonumber(data.amount) > 0 then
        TriggerServerEvent('banking:deposit', tonumber(data.amount))
    end
    cb('ok')
end)

RegisterNUICallback("withdraw", function(data, cb)
    if data.amount and tonumber(data.amount) > 0 then
        TriggerServerEvent('banking:withdraw', tonumber(data.amount))
    end
    cb('ok')
end)

RegisterNUICallback("transfer", function(data, cb)
    if data.amount and data.target and tonumber(data.amount) > 0 then
        TriggerServerEvent('banking:transfer', data.target, tonumber(data.amount))
    end
    cb('ok')
end)

RegisterNetEvent('banking:setBalance')
AddEventHandler('banking:setBalance', function(balance)
    SendNUIMessage({
        type = "balance",
        balance = balance
    })
end)

RegisterNetEvent('banking:setTransactions')
AddEventHandler('banking:setTransactions', function(transactions)
    SendNUIMessage({
        type = "transactions",
        transactions = transactions
    })
end)

RegisterNetEvent('banking:setIBAN')
AddEventHandler('banking:setIBAN', function(iban)
    SendNUIMessage({
        type = "setIBAN",
        iban = iban
    })
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function()
    TriggerServerEvent('banking:initializeAccount')
end)

AddEventHandler('onResourceStop', function(resourceName)
    if (GetCurrentResourceName() ~= resourceName) then
        return
    end
    
    if display then
        CloseBankingUI()
    end
end)

