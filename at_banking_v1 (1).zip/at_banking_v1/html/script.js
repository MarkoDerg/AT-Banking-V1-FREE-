document.addEventListener('DOMContentLoaded', () => {
    window.addEventListener('message', function(event) {
        switch (event.data.type) {
            case "ui":
                const container = document.querySelector('.main__genisis-banking-container');
                if (container) {
                    container.style.display = event.data.display ? "block" : "none";
                }
                break;
            case "balance":
                const balanceElement = document.querySelector('.main__genisis-banking-top-grid-blur-right-text p:nth-child(2)');
                if (balanceElement) {
                    balanceElement.textContent = event.data.balance;
                }
                break;
            case "transactions":
                updateTransactions(event.data.transactions);
                break;
            case "playerInfo":
                const holderElement = document.querySelector('.main__genisis-banking-top-grid-bottom-left p:nth-child(2)');
                if (holderElement) {
                    holderElement.textContent = `${event.data.firstName} ${event.data.lastName}`.toUpperCase();
                }
                break;
        }
    });

    setupBankingActions();
});

function setupBankingActions() {
    const closeBtn = document.querySelector('.fa-xmark');
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            sendNUICallback('close');
        });
    }
    setupActionButton('deposit');
    setupActionButton('withdraw');
    setupActionButton('transfer');
}

function setupActionButton(type) {
    const mainBtn = document.querySelector(`.main__genisis-banking-middle-grid-item-1.${type}`);
    const container = mainBtn?.closest('.main__genisis-banking-middle-grid-item-container');
    if (!mainBtn || !container) return;

    mainBtn.addEventListener('click', () => {
        container.classList.add('active');
    });

    const cancelBtn = container.querySelector('.main__genisis-banking-middle-grid-item-2-interact-btn.red');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', () => {
            container.classList.remove('active');
            resetForm(container);
        });
    }

    const submitBtn = container.querySelector('.main__genisis-banking-middle-grid-item-2-interact-btn:not(.red)');
    if (submitBtn) {
        submitBtn.addEventListener('click', () => {
            handleSubmit(type, container);
        });
    }
}

function handleSubmit(type, container) {
    const amountInput = container.querySelector('input[placeholder="Menge?"]');
    const amount = amountInput ? parseFloat(amountInput.value) : 0;

    if (!validateAmount(amount)) return;

    if (type === 'transfer') {
        const targetInput = container.querySelector('input[placeholder="IBAN?"]');
        const target = targetInput ? targetInput.value : '';
        if (!validateTarget(target)) return;
        sendNUICallback(type, { amount, target });
    } else {
        sendNUICallback(type, { amount });
    }

    container.classList.remove('active');
    resetForm(container);
}

function resetForm(container) {
    const inputs = container.querySelectorAll('input');
    inputs.forEach(input => input.value = '');
}

function validateAmount(amount) {
    if (isNaN(amount) || amount <= 0) {
        showNotification('Bitte gib einen gültigen Betrag ein');
        return false;
    }
    return true;
}

function validateTarget(target) {
    if (!target || target.trim().length === 0) {
        showNotification('Bitte gib eine gültige IBAN ein');
        return false;
    }
    return true;
}

function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'banking-notification';
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.classList.add('fade-out');
        setTimeout(() => notification.remove(), 500);
    }, 3000);
}

function updateTransactions(transactions) {
    const container = document.querySelector('.main__genisis-banking-bottom-scroll-container');
    if (!container) return;

    container.innerHTML = '';

    transactions.forEach(transaction => {
        const item = createTransactionItem(transaction);
        container.appendChild(item);
    });
}

function createTransactionItem(transaction) {
    const item = document.createElement('div');
    item.className = 'main__genisis-banking-bottom-scroll-item';

    const isNegative = ['withdraw', 'transfer_sent'].includes(transaction.type);
    const amount = isNegative ? `-${transaction.amount}` : `+${transaction.amount}`;
    const date = new Date(transaction.date).toLocaleString('de-DE');

    item.innerHTML = `
        <div class="main__genisis-banking-bottom-scroll-item-info">
            <p>Tx ID</p>
            <p>${transaction.id}</p>
        </div>
        <div class="main__genisis-banking-bottom-scroll-sphere ${isNegative ? 'withdraw' : ''}"></div>
        <div class="main__genisis-banking-bottom-scroll-item-info center">
            <p>Typ</p>
            <p>${getTransactionType(transaction.type)}</p>
        </div>
        <div class="main__genisis-banking-bottom-scroll-item-info center">
            <p>Menge</p>
            <p>${amount}$</p>
        </div>
        <div class="main__genisis-banking-bottom-scroll-item-info right">
            <p>Datum</p>
            <p>${date}</p>
        </div>
        <div class="main__genisis-banking-bottom-scroll-item-border"></div>
    `;

    return item;
}

function getTransactionType(type) {
    const types = {
        'deposit': 'Einzahlung',
        'withdraw': 'Auszahlung',
        'transfer_sent': 'Überweisung gesendet',
        'transfer_received': 'Überweisung erhalten',
        'paycheck': 'Gehalt'
    };
    return types[type] || type;
}

function sendNUICallback(action, data = {}) {
    fetch(`https://${GetParentResourceName()}/${action}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify(data)
    }).catch(err => {
        console.error('Error in sendNUICallback', err);
    });
}

// ESC key handler
document.addEventListener('keyup', function(e) {
    if (e.key === "Escape") {
        sendNUICallback('close');
    }
});
