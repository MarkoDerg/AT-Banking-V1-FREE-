fx_version 'cerulean'
game 'gta5'

author 'MarkoTkm'
description 'Das Beste Banking Auf Dem Fivem Markt'
version '1.0.0'

shared_scripts {
    '@es_extended/imports.lua',
    'config.lua'
}

client_scripts {
    'client/client.lua'
}

server_scripts {
    '@mysql-async/lib/MySQL.lua',
    'server/server.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/config.css',
    'html/index.css',
    'html/script.js',
    'html/img/*.png',
    'html/img/banking/*.png'
}

dependencies {
    'es_extended',
    'mysql-async'
}